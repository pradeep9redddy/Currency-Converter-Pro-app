package com.example.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;

import static java.lang.Math.round;

public class MainActivity extends AppCompatActivity {
    TextView conversionRateText;
    EditText amountToConvert;
    Spinner spfrom, spto;
    ArrayList<String> arrayList;
    Button convertButton,history;
    ListView list;
    String convertFromValue, convertToValue, conversionValue;
    Model model1;
    Double amountToConvert1;
    Double conversionRes_value;
    ArrayAdapter customerArrayAdapter;
    Double ratioOf;
    DataBase dataBase1;
    Double conversionValue_int;

    public String getConversionRates(final String convertFrom, final String convertTo, final Double amountToconvert){

        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        String url = "https://free.currconv.com/api/v7/convert?q=" + convertFromValue +"_"+ convertToValue + "&compact=ultra&apiKey=965ba5e244dec7da263d";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                JSONObject jsonObject = null;
                Toast.makeText(MainActivity.this,response,Toast.LENGTH_LONG).show();
                try {
                    jsonObject = new JSONObject(response);
                    conversionRes_value = round(((Double) jsonObject.get(convertFromValue + "_" + convertToValue)),6);
                    conversionValue = ""+round((conversionRes_value* amountToconvert),2);
                    conversionRateText.setText(conversionValue);
                    //modelUpdate(convertFromValue, convertToValue, conversionRes_value,amountToConvert1,conversionRateText.getText().toString());
                    Toast.makeText(MainActivity.this,"Inside response",Toast.LENGTH_SHORT).show();
                    //model1 = new Model(-1, convertFromValue, convertToValue, conversionRes_value,amountToConvert1,conversionRateText.getText().toString());
                    //Toast.makeText(MainActivity.this,model1.toString(),Toast.LENGTH_SHORT).show();

                } catch (JSONException e) {
                    Toast.makeText(MainActivity.this,"error in response",Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        },new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        queue.add(stringRequest);
        return null;
    }

    //ArrayList<String> countries = new ArrayList<>();
    String[] countries = {"USD", "INR", "EUR", "AUD","PHP"};

    class CountriesSpinnerClass implements AdapterView.OnItemSelectedListener {
        public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
            convertFromValue = parent.getItemAtPosition(position).toString();
            //Toast.makeText(v.getContext(), "Your choose :" + countries[position], Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
            Toast.makeText(MainActivity.this, "Nothing WAS Selected", Toast.LENGTH_SHORT).show();
        }
    }

    class CitiesSpinnerClass implements AdapterView.OnItemSelectedListener {
        public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
            convertToValue = parent.getItemAtPosition(pos).toString();
            //Toast.makeText(v.getContext(), "Your choose :" + countries[pos], Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
            Toast.makeText(MainActivity.this, "Nothing WAS Selected", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spfrom = findViewById(R.id.spinner);
        spto = findViewById(R.id.spinner2);
        list = findViewById(R.id.l1);
        conversionRateText = findViewById(R.id.conversionRateText);
        convertButton = findViewById(R.id.conversionButton);
        amountToConvert = findViewById(R.id.amountToConvertValueEditText);
        history = findViewById(R.id.button2);


        ArrayAdapter<String> aa = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, countries);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spfrom.setAdapter(aa);
        spfrom.setOnItemSelectedListener(new CountriesSpinnerClass());

        ArrayAdapter<String> bb = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, countries);
        bb.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spto.setAdapter(bb);
        spto.setOnItemSelectedListener(new CitiesSpinnerClass());
        dataBase1 = new DataBase(MainActivity.this);
        ShowUpdatedListView(dataBase1);


        convertButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            public void onClick(View v) {

                try {
                    if(convertToValue == convertFromValue){
                        Toast.makeText(MainActivity.this, "CANNOT CONVERT THE SAME CURRENCY", Toast.LENGTH_SHORT).show();
                        throw new IllegalArgumentException();
                    }
                    else{
                        amountToConvert1 = Double.valueOf(MainActivity.this.amountToConvert.getText().toString());
                        getConversionRates(convertFromValue,convertToValue,amountToConvert1);
                        Toast.makeText(MainActivity.this, "SUCCESS INSIDE THE BUTTON", Toast.LENGTH_SHORT).show();
                        //Toast.makeText(MainActivity.this, "success ratio inside BUTTON" + conversionRes_value, Toast.LENGTH_SHORT).show();
                        //Toast.makeText(MainActivity.this, "success final value inside BUTTON" + conversionValue, Toast.LENGTH_SHORT).show();

                        }
                }
                catch (Exception e){
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this,"THIS IS TO SAY BUTTON ERROR",Toast.LENGTH_SHORT).show();
                    model1 = new Model(-1,null,null,0.0,0.0,null);
                }
                dataBase1 = new DataBase(MainActivity.this);
//                boolean success = dataBase1.addData(model1);
//                Toast.makeText(MainActivity.this, "success" + success, Toast.LENGTH_SHORT).show();
                ShowUpdatedListView(dataBase1);


            }
        });

        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(MainActivity.this,"history",Toast.LENGTH_SHORT).show();
                try {
                    model1 = new Model(-1, convertFromValue, convertToValue, conversionRes_value,amountToConvert1,conversionRateText.getText().toString());


                    Toast.makeText(MainActivity.this,model1.toString(),Toast.LENGTH_SHORT).show();

                    Toast.makeText(MainActivity.this,"SUCCESS BUTTON --HISTORY--",Toast.LENGTH_SHORT).show();

                }
                catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this,"Error Creating customer",Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
                dataBase1 = new DataBase(MainActivity.this);
                boolean success = dataBase1.addData(model1);
                Toast.makeText(MainActivity.this, "success" + success, Toast.LENGTH_SHORT).show();
                ShowUpdatedListView(dataBase1);
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Model clickedCustomer = (Model) parent.getItemAtPosition(position);
                //DataBase dataBase2 = new DataBase(MainActivity.this);
                dataBase1.deleteData(clickedCustomer);
                ShowUpdatedListView(dataBase1);
                Toast.makeText(MainActivity.this,"Deleted "+clickedCustomer.toString(),Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void ShowUpdatedListView(DataBase dataBase12) {
        customerArrayAdapter = new ArrayAdapter<Model>(MainActivity.this, android.R.layout.simple_list_item_1, dataBase12.getEveryone());
        list.setAdapter(customerArrayAdapter);
    }


    public static double round(double value,int places){
        if(places<0) throw new IllegalArgumentException();
        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
}



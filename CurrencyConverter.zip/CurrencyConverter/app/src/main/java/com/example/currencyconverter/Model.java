package com.example.currencyconverter;

public class Model {
    private int id;
    private String From;
    private String To;
    private Double Ratio;
    private Double Amount;
    private String convertedResult;

//////////////////////////////

    public Model(int id, String from, String to, Double ratio, Double amount, String convertedResult) {
        this.id = id;
        this.From = from;
        this.To = to;
        this.Ratio = ratio;
        this.Amount = amount;
        this.convertedResult = convertedResult;
    }

    @Override
    public String toString() {
        return "Model{" +
                "id=" + id +
                ", From='" + From + '\'' +
                ", To='" + To + '\'' +
                ", Ratio=" + Ratio +
                ", Amount=" + Amount +
                ", convertedResult='" + convertedResult + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFrom() {
        return From;
    }

    public void setFrom(String from) {
        From = from;
    }

    public String getTo() {
        return To;
    }

    public void setTo(String to) {
        To = to;
    }

    public Double getRatio() {
        return Ratio;
    }

    public void setRatio(Double ratio) {
        Ratio = ratio;
    }

    public Double getAmount() {
        return Amount;
    }

    public void setAmount(Double amount) {
        Amount = amount;
    }

    public String getConvertedResult() {
        return convertedResult;
    }

    public void setConvertedResult(String convertedResult) {
        this.convertedResult = convertedResult;
    }
/*Model(int id, String fromm, String to1, Double ratio, Double amount, String converted) {
        this.id = id;
        this.From = fromm;
        this.to1 = to1;
        this.ratio = ratio;
        this.amount = amount;
        this.converted = converted;


    }
    public Model(){

    }
////////

    @Override
    public String toString() {
        return "Model{" +
                "id=" + id +
                ", fromm='" + From + '\'' +
                ", to1='" + to1 + '\'' +
                ", ratio=" + ratio +
                ", amount=" + amount +
                ", converted='" + converted + '\'' +
                '}';
    }


    ////////

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFromm() {
        return From;
    }

    public void setFromm(String fromm) {
        this.From = fromm;
    }

    public String getTo1() {
        return to1;
    }

    public void setTo1(String to1) {
        this.to1 = to1;
    }

    public Double getRatio() {
        return ratio;
    }

    public void setRatio(Double ratio) {
        this.ratio = ratio;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getConverted() {
        return converted;
    }

    public void setConverted(String converted) {
        this.converted = converted;
    }*/
}

package com.example.currencyconverter;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.renderscript.Double2;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DataBase extends SQLiteOpenHelper {
    private static final String CUSTOMER_TABLE = "COSTUMER_TABLE";
    private static final String COLUMN_ID = "ID";
    private static final String COLUMN_FROM_CURRENCY = "FROMM";
    private static final String COLUMN_TO_CURRENCY = "TO1";
    private static final String COLUMN_RATIO = "RATIO";
    private static final String COLUMN_AMOUNT = "AMOUNT";
    private static final String COLUMN_CONVERTED = "CONVERTED";

    DataBase(@Nullable Context context) {
        super(context, "Customer.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + CUSTOMER_TABLE + " ( " + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_FROM_CURRENCY + " TEXT, " + COLUMN_TO_CURRENCY + " TEXT, " + COLUMN_RATIO + " DOUBLE, " + COLUMN_AMOUNT+" DOUBLE, "+ COLUMN_CONVERTED + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE "+ CUSTOMER_TABLE);
        onCreate(db);
    }

    public boolean addData(Model model1){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        //contentValues.put(COLUMN_ID, model1.getId());
        contentValues.put(COLUMN_FROM_CURRENCY, model1.getFrom());
        contentValues.put(COLUMN_TO_CURRENCY, model1.getTo());
        contentValues.put(COLUMN_RATIO, model1.getRatio());
        contentValues.put(COLUMN_AMOUNT, model1.getAmount());
        contentValues.put(COLUMN_CONVERTED, model1.getConvertedResult());

            Log.d("sql","adding data " + model1.toString() + " to " + CUSTOMER_TABLE);
            long insert = db.insert(CUSTOMER_TABLE, null, contentValues);

            //db.close();
            if (insert == -1) {
                return false;
            } else {
                return true;
            }
    };

    public  boolean deleteData(Model model1){
        SQLiteDatabase db = this.getWritableDatabase();
        String queryString = "DELETE FROM " + CUSTOMER_TABLE +" WHERE " + COLUMN_ID + "=" + model1.getId();
        Cursor cursor = db.rawQuery(queryString, null);
        if(cursor.moveToFirst()){
            return true;
        }
        else{
            return false;
        }
    }

    List<Model> getEveryone(){
        List<Model> returnList = new ArrayList<>();
        String queryString = " SELECT * FROM " + CUSTOMER_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString,null);

        if (cursor!=null && cursor.getCount() > 0 && cursor.moveToFirst()){
                System.out.println("String   fdv");
            do{
                int CustomerID = cursor.getInt(0);
                String From = cursor.getString(1);
                String To = cursor.getString(2);
                Double Ratio = cursor.getDouble(3);
                Double Amount = cursor.getDouble(4);
                String ConvertedResult = cursor.getString(5);

                Model newModel= new Model(CustomerID,From,To,Ratio,Amount,ConvertedResult);
                returnList.add(newModel);
            }while (cursor.moveToNext());
        }
        else{
            //Toast.makeText(MainActivity.this,"DATABASE NOT WORKING",Toast.LENGTH_SHORT).show();
            System.out.println("DATA   base    not ");
        }
        //nothing to do

        assert cursor != null;
        cursor.close();
        db.close();
        return returnList;
    }
}